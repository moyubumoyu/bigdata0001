package app;

import view.MainView;

public class MainApp {
    public static void main(String[] args) {
        //new MainView().login();
        new MainView().UserView();
    }
}
