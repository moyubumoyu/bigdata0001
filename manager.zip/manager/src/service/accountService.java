package service;
import entity.account;
import dao.accountDao;

import java.util.List;
import java.util.Scanner;

public class accountService {
    Scanner sc = new Scanner(System.in);
    private accountDao dao = new accountDao();
    public void queryAll(){
        String sql = "select * from account";
        List<account> list = dao.findAll(sql, account.class);
        for(account i: list){
            System.out.println(i.getId()+"\t"+i.getCname()+"\t"+i.getMoney());
        }
    }
    public void queryOne(){
        System.out.println("输入要查询的账务id:");
        int id = sc.nextInt();

        String sql = "select * from account where id=?";
        account account = (account) dao.findOne(sql,account.class,id);
        System.out.println(account.getId()+"\t"+account.getCname()+"\t"+account.getMoney()+"\t"+account.getPaytype()+"\t"+account.getCreatetime()+"\t"+account.getDescription());
    }
    public void insertAccount(){
        System.out.println("请输入要插入的账务信息");
        System.out.println("id:");
        int id = sc.nextInt();
        System.out.println("分类名称：");
        String cname = sc.next();
        System.out.println("金额：");
        int money = sc.nextInt();
        System.out.println("支出类型：");
        String paytype = sc.next();
        System.out.println("创建日期：");
        String createtime = sc.next();
        System.out.println("账务描述：");
        String description = sc.next();

        account account = new account(id,cname,money,paytype,createtime,description);

        String sql = "insert into account values(?,?,?,?,?,?)";
        int a = dao.insertT(sql,id,cname,money,paytype,createtime,description);
        if(a>0){
            System.out.println("添加成功");
        }else {
            System.out.println("添加失败");
        }
    }
    public void deleteAccount(){
        System.out.println("输入要删除的账务id:");
        int id = sc.nextInt();

        String sql = "delete from account where id=?";
        int a = dao.deleteT(sql,id);
        if(a>0){
            System.out.println("删除成功");
        }else {
            System.out.println("删除失败");
        }
    }
    public void updateAccount(){
        System.out.println("输入要修改的账务id:");
        int id = sc.nextInt();
        System.out.println("输入要修改的金额：");
        int money = sc.nextInt();

        String sql = "update account set money=? where id=?";
        int a = dao.updateT(sql,money,id);
        if(a>0){
            System.out.println("修改成功");
        }else {
            System.out.println("修改失败");
        }
    }
}
