package view;

import entity.User;
import service.UserService;
import service.accountService;

import java.util.Scanner;

public class MainView {
    UserService userService = new UserService();
    accountService ac = new accountService();

    Scanner sc = new Scanner(System.in);
    public void UserView(){
        while (true){
            System.out.println("*********用户管理系统**********");
            System.out.println("请输入你的操作 1：登录 2：注册 3：修改 4：删除 5：查询 任意键退出");

            int n =sc.nextInt();
            switch (n){
                case 1:
                    login();
                    break;
                case 2:
                    userService.insertUser();
                    break;
                case 3:
                    userService.updateUser();
                    break;
                case 4:
                    userService.deleteUser();
                    break;
                case 5:
                    userService.queryAll();
                    break;
                default:
                    System.out.println("bye bye");
                    System.exit(0);
                    break;
            }
        }
    }

    public void login(){
        User u = userService.login();
        if(u==null){
            System.out.println("用户名或密码错误，请重新登录");
        }else {
            System.out.println("登录成功");
            zwManagerView();
        }
    }
    public void zwManagerView(){
        while(true){
            System.out.println("*************账务管理系统**************");
            System.out.println("请输入你要进行的操作 1:添加账务 2:编辑账务 3:删除账务 4:查询账务  任意键退出");

            int n = sc.nextInt();
            switch (n){
                case 1:
                    ac.insertAccount();
                    break;
                case 2:
                    ac.updateAccount();
                    break;
                case 3:
                    ac.deleteAccount();
                    break;
                case 4:
                    query();
                    break;
                default:
                    System.out.println("bye bye");
                    System.exit(0);
                    break;
            }

        }
    }
    private void query(){
        System.out.println("1:查询所有 2:按id查询");
        int chose = sc.nextInt();
        switch (chose){
            case 1:
                ac.queryAll();
                break;
            case 2:
                ac.queryOne();
            default:
                break;
        }
    }
}
